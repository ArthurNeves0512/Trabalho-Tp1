/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

public class Cliente {
    String nome;
    String rg;
    String id;
    String cpf;
    String telefone;

    public Cliente() {
    }

    public Cliente(String nome, String rg, String id, String cpf, String telefone) {
        this.nome = nome;
        this.rg = rg;
        this.id = id;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    
    public String getNome() {
        return nome;
    }

    public String getRg() {
        return rg;
    }

    public String getId() {
        return id;
    }

    public String getCpf() {
        return cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
}
