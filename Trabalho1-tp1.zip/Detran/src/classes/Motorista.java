/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

public class Motorista {
    String nome;;
    String id;
    String telefone;
    String Cnh;

    public Motorista() {
    }

    public Motorista(String nome, String id, String telefone, String Cnh) {
        this.nome = nome;
        this.id = id;
        this.telefone = telefone;
        this.Cnh = Cnh;
    }

    public String getNome() {
        return nome;
    }

    public String getId() {
        return id;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getCnh() {
        return Cnh;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setCnh(String Cnh) {
        this.Cnh = Cnh;
    }
    
}
