/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;

import java.util.ArrayList;

public class Chamado {
   String id; String Data; String Tipo; String origem; String destino;
   String horarioPartida; String horarioRetorno; double KmInicial;
   double KmFinal; double valor;
   String motorista; String passageiro;
   ArrayList listaChamados = new ArrayList();
    public Chamado(String motorista, String passageiro,String id, String Data, String Tipo, String origem, String destino, String horarioPartida,
            String horarioRetorno, double KmInicial, double KmFinal, double valor) {
        this.motorista = motorista;
        this.passageiro =passageiro;
        this.id = id;
        this.Data = Data;
        this.Tipo = Tipo;
        this.origem = origem;
        this.destino = destino;
        this.horarioPartida = horarioPartida;
        this.horarioRetorno = horarioRetorno;
        this.KmInicial = KmInicial;
        this.KmFinal = KmFinal;
        this.valor = valor;
    }

   
    public String getId() {
        return id;
    }

    public String getData() {
        return Data;
    }

    public String getTipo() {
        return Tipo;
    }

    public String getOrigem() {
        return origem;
    }
    public String getMotorista(){
        return motorista;
    }
    public void setMotorista(String motorista){
        this.motorista = motorista;
    }

    public String getPassageiro() {
        return passageiro;
    }

    public void setPassageiro(String passageiro) {
        this.passageiro = passageiro;
    }
    
    public String getDestino() {
        return destino;
    }

    public String getHorarioPartida() {
        return horarioPartida;
    }

    public String getHorarioRetorno() {
        return horarioRetorno;
    }

    public double getKmInicial() {
        return KmInicial;
    }

    public double getKmFinal() {
        return KmFinal;
    }

    public double getValor() {
        return valor;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setData(String Data) {
        this.Data = Data;
    }

    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setHorarioPartida(String horarioPartida) {
        this.horarioPartida = horarioPartida;
    }

    public void setHorarioRetorno(String horarioRetorno) {
        this.horarioRetorno = horarioRetorno;
    }

    public void setKmInicial(double KmInicial) {
        this.KmInicial = KmInicial;
    }

    public void setKmFinal(double KmFinal) {
        this.KmFinal = KmFinal;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
   
}
